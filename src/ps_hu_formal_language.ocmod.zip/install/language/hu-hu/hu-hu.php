<?php
// Text
$_['text_name']       = 'Magyar';
$_['text_loading']    = 'Betöltés...';

// Button
$_['button_continue'] = 'Tovább';
$_['button_back']     = 'Vissza';

// Error
$_['error_exception'] = 'Hibakód (%s): %s itt: %s a %s sorban';
