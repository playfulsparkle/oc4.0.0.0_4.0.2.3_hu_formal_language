<?php
// Text
$_['text_project']       = 'Projekt kezdőlap';
$_['text_documentation'] = 'Dokumentáció';
$_['text_support']       = 'Támogatási fórumok';
$_['text_footer']  = '<a href="https://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' Minden jog fenntartva.';