<?php
// Text
$_['text_recommended'] = 'Ajánlott';
$_['text_install']     = 'Telepítés';
$_['text_uninstall']   = 'Eltávolítás';
$_['text_delete']      = 'Törlés';
