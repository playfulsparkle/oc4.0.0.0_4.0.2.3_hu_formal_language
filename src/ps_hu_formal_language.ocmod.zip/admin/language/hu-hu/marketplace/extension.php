<?php
// Heading
$_['heading_title'] = 'Bővítmények';

// Text
$_['text_success']  = 'Siker: A bővítmények sikeresen módosítva lettek!';
$_['text_list']     = 'Bővítmény lista';
$_['text_type']     = 'Válassza ki a bővítmény típusát';
$_['text_filter']   = 'Szűrő';
