<?php
// Heading
$_['heading_title']     = 'Üzembe helyezés';

// Text
$_['text_success']      = 'Siker: Sikeresen módosította a üzembe helyezéseket!';
$_['text_list']         = 'Üzembe helyezés lista';

// Column
$_['column_code']       = 'Módosítás kód';
$_['column_sort_order'] = 'Sorrend';
$_['column_action']     = 'Művelet';

// Error
$_['error_permission']  = 'Figyelem: Nincs jogosultsága a üzembe helyezés végrehajtásához!';
