<?php
// Text
$_['error_language'] = 'Figyelmeztetés: A nyelv nem található!';
