<?php
// Heading
$_['heading_title']          = 'OpenCart';

// Text
$_['text_notification']      = 'Értesítések';
$_['text_notification_all']  = 'Összes megtekintése';
$_['text_notification_none'] = 'Nincsenek értesítések';
$_['text_profile']           = 'Profil';
$_['text_store']             = 'Áruházak';
$_['text_help']              = 'Segítség';
$_['text_homepage']          = 'OpenCart kezdőlap';
$_['text_support']           = 'Támogatási fórum';
$_['text_documentation']     = 'Dokumentáció';
$_['text_logout']            = 'Kijelentkezés';
