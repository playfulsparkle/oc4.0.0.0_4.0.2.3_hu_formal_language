<?php
// Heading
$_['heading_title']         = 'Vásárlói jogosultságok';

// Text
$_['text_success']          = 'Siker: Sikeresen módosította a vásárlói jogosultságokat!';
$_['text_list']             = 'Vásárlói jogosultság lista';
$_['text_default']          = 'Alapértelmezett';
$_['text_customer']         = 'Vásárló';
$_['text_affiliate']        = 'Partner';
$_['text_filter']           = 'Szűrő';
$_['text_approve']          = 'Jóváhagyás';
$_['text_deny']             = 'Elutasítás';

// Column
$_['column_customer']       = 'Vásárló';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Vásárlói Csoport';
$_['column_type']           = 'Típus';
$_['column_date_added']     = 'Hozzáadva';
$_['column_action']         = 'Művelet';

// Entry
$_['entry_customer']        = 'Vásárló';
$_['entry_email']           = 'E-Mail';
$_['entry_customer_group']  = 'Vásárlói Csoport';
$_['entry_type']            = 'Típus';
$_['entry_date_from']       = 'Dátumtól';
$_['entry_date_to']         = 'Dátumig';

// Error
$_['error_permission']      = 'Figyelem: Nincs engedélye a vásárlói jogosultságok módosítására!';
