<?php
// Heading
$_['heading_title']     = 'Irányítópult';

// Text
$_['text_success']      = 'Siker: Az irányítópult sikeresen módosítva lett!';
$_['text_list']         = 'Irányítópult lista';

// Column
$_['column_name']       = 'Irányítópult név';
$_['column_width']      = 'Szélesség';
$_['column_status']     = 'Állapot';
$_['column_sort_order'] = 'Sorrend';
$_['column_action']     = 'Művelet';

// Error
$_['error_permission']  = 'Figyelem: Nincs jogosultsága az irányítópultok módosításához!';
$_['error_extension']   = 'Figyelem: A bővítmény nem létezik!';
