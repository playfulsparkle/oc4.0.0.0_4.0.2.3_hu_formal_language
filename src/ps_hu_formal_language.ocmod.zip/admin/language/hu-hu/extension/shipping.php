<?php
// Heading
$_['heading_title']     = 'Szállítás';

// Text
$_['text_success']      = 'Siker: Szállítás módosítva!';
$_['text_list']         = 'Szállítás listája';

// Column
$_['column_name']       = 'Szállítás név';
$_['column_status']     = 'Állapot';
$_['column_sort_order'] = 'Sorrend';
$_['column_action']     = 'Művelet';

// Error
$_['error_permission']  = 'Figyelmeztetés: Nincs jogosultsága a szállítás módosításához!';
$_['error_extension']   = 'Figyelmeztetés: A bővítmény nem létezik!';
