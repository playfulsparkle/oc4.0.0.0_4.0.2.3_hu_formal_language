<?php
// Heading
$_['heading_title']     = 'Jelentések';

// Text
$_['text_success']      = 'Siker: Jelentések módosítva!';
$_['text_list']         = 'Jelentések listája';

// Column
$_['column_name']       = 'Jelentés név';
$_['column_status']     = 'Állapot';
$_['column_sort_order'] = 'Sorrend';
$_['column_action']     = 'Művelet';

// Error
$_['error_permission']  = 'Figyelmeztetés: Nincs jogosultsága a jelentések módosításához!';
$_['error_extension']   = 'Figyelmeztetés: A bővítmény nem létezik!';
