<?php
// Heading
$_['heading_title']     = 'Rendelés összegzése';

// Text
$_['text_success']      = 'Siker: Rendelés összegzése módosítva!';

// Column
$_['column_name']       = 'Rendelési Összesítő';
$_['column_status']     = 'Állapot';
$_['column_sort_order'] = 'Sorrend';
$_['column_action']     = 'Művelet';

// Error
$_['error_permission']  = 'Figyelmeztetés: Nincs jogosultsága az összesítők módosításához!';
$_['error_extension']   = 'Figyelmeztetés: A bővítmény nem létezik!';
