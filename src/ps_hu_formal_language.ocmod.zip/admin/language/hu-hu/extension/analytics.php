<?php
// Heading
$_['heading_title']    = 'Analitika';

// Text
$_['text_success']     = 'Siker: Az analitikai beállítások sikeresen módosítva lettek!';
$_['text_list']        = 'Analitika lista';

// Column
$_['column_name']      = 'Analitika név';
$_['column_status']    = 'Állapot';
$_['column_action']    = 'Művelet';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az analitika módosításához!';
$_['error_extension']  = 'Figyelem: A bővítmény nem létezik!';
