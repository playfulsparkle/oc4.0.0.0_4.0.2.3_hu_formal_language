<?php
// Heading
$_['heading_title']    = 'Piacterek';

// Text
$_['text_success']     = 'Siker: A piacterek sikeresen módosítva lettek!';
$_['text_list']        = 'Piacterek lista';

// Column
$_['column_name']      = 'Piactér név';
$_['column_status']    = 'Állapot';
$_['column_action']    = 'Művelet';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága a piacterek módosításához!';
$_['error_extension']  = 'Figyelem: A bővítmény nem létezik!';
