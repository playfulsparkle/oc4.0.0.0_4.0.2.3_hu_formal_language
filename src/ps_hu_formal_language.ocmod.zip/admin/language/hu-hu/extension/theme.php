<?php
// Heading
$_['heading_title']    = 'Témák';

// Text
$_['text_success']     = 'Siker: Témák módosítva!';

// Column
$_['column_name']      = 'Téma név';
$_['column_status']    = 'Állapot';
$_['column_action']    = 'Művelet';

// Error
$_['error_permission'] = 'Figyelmeztetés: Nincs jogosultsága a témák módosításához!';
$_['error_extension']  = 'Figyelmeztetés: A bővítmény nem létezik!';
