<?php
// Heading
$_['heading_title']    = 'Csalás elleni védelem';

// Text
$_['text_success']     = 'Siker: A csalás elleni védelem sikeresen módosítva lett!';
$_['text_list']        = 'Csalás elleni védelem lista';

// Column
$_['column_name']      = 'Csalás elleni védelem név';
$_['column_status']    = 'Állapot';
$_['column_action']    = 'Művelet';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága a csalás elleni védelem módosításához!';
$_['error_extension']  = 'Figyelem: A bővítmény nem létezik!';
