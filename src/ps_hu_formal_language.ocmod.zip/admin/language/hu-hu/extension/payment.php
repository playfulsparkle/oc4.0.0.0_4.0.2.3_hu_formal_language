<?php
// Heading
$_['heading_title']     = 'Fizetési lehetőségek';

// Text
$_['text_success']      = 'Siker: A fizetési lehetőségek sikeresen módosítva lettek!';
$_['text_list']         = 'Fizetési lehetőségek Lista';

// Column
$_['column_name']       = 'Fizetési Módszer';
$_['column_vendor']     = 'Szállító';
$_['column_status']     = 'Állapot';
$_['column_sort_order'] = 'Sorrend';
$_['column_action']     = 'Művelet';

// Error
$_['error_permission']  = 'Figyelem: Nincs jogosultsága a fizetési lehetőségek módosításához!';
$_['error_extension']   = 'Figyelem: A bővítmény nem létezik!';
