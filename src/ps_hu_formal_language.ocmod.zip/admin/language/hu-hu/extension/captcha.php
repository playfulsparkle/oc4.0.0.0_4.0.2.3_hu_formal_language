<?php
// Heading
$_['heading_title']    = 'Captcha';

// Text
$_['text_success']     = 'Siker: A captcha sikeresen módosítva lett!';
$_['text_list']        = 'Captcha lista';

// Column
$_['column_name']      = 'Captcha név';
$_['column_status']    = 'Állapot';
$_['column_action']    = 'Művelet';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága a captcha-k módosításához!';
$_['error_extension']  = 'Figyelem: A bővítmény nem létezik!';
