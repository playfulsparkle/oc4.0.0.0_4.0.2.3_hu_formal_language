<?php
// Heading Title
$_['heading_title'] = 'Promóció';
