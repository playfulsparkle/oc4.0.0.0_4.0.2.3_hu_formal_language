<?php
// Heading
$_['heading_title']    = 'Nyelvek';

// Text
$_['text_success']     = 'Siker: A nyelvek sikeresen módosítva lettek!';
$_['text_list']        = 'Nyelvi lista';

// Column
$_['column_name']      = 'Nyelv név';
$_['column_status']    = 'Állapot';
$_['column_action']    = 'Művelet';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága a nyelvek módosításához!';
$_['error_extension']  = 'Figyelem: A bővítmény nem létezik!';
