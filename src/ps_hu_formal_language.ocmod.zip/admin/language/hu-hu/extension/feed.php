<?php
// Heading
$_['heading_title']    = 'Adatfolyamok';

// Text
$_['text_success']     = 'Siker: Az adatfolyamok sikeresen módosítva lettek!';
$_['text_list']        = 'Adatfolyam lista';

// Column
$_['column_name']      = 'Termék adatfolyam neve';
$_['column_status']    = 'Állapot';
$_['column_action']    = 'Művelet';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az adatfolyamok módosításához!';
$_['error_extension']  = 'Figyelem: A bővítmény nem létezik!';
