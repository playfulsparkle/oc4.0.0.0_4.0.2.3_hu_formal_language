<?php
// Heading
$_['heading_title']    = 'Valutaárfolyamok';

// Text
$_['text_success']     = 'Siker: A valutaárfolyamok sikeresen módosítva lettek!';
$_['text_list']        = 'Valutaárfolyam lista';

// Column
$_['column_name']      = 'Valutaárfolyam neve';
$_['column_status']    = 'Állapot';
$_['column_action']    = 'Művelet';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága a valutaárfolyamok módosításához!';
$_['error_extension']  = 'Figyelem: A bővítmény nem létezik!';
