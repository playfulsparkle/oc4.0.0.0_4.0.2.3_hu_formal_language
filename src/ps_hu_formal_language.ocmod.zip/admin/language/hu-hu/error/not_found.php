<?php
// Heading
$_['heading_title']  = 'Az oldal nem található!';

// Text
$_['text_not_found'] = 'A keresett oldal nem található! Kérjük, lépjen kapcsolatba a rendszergazdával, ha a probléma továbbra is fennáll.';
