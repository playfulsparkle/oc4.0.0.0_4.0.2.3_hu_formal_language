<?php
// Heading
$_['heading_title']   = 'Hozzáférés megtagadva!';

// Text
$_['text_permission'] = 'Önnek nincs jogosultsága az oldal eléréséhez, kérjük, forduljon a rendszergazdához.';
