<?php
// Heading
$_['heading_title']    = 'Hibanapló';

// Text
$_['text_success']     = 'Siker: Sikeresen törölte a hibanaplót!';
$_['text_list']        = 'Hibák listája';

// Error
$_['error_permission'] = 'Figyelmeztetés: Nincs engedélyed a hibanapló törlésére!';
$_['error_file']       = 'Figyelmeztetés: A(z) %s fájl nem található!';
$_['error_size']       = 'Figyelmeztetés: A hibanapló fájl %s mérete %s!';
$_['error_empty']      = 'Figyelmeztetés: A(z) %s napló üres!';
