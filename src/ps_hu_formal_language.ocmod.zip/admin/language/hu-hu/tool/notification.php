<?php
// Heading
$_['heading_title']    = 'Értesítések';

// Text
$_['text_success']     = 'Siker: Sikeresen módosította az értesítéseket!';
$_['text_list']        = 'Értesítések listája';

// Column
$_['column_message']   = 'Üzenet';
$_['column_action']    = 'Művelet';

// Error
$_['error_permission'] = 'Figyelmeztetés: Nincs engedélyed az értesítések módosítására!';
