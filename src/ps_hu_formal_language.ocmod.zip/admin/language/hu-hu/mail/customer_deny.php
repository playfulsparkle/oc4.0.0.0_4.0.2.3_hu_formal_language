<?php
// Text
$_['text_subject']   = '%s - A fiókját elutasították!';
$_['text_welcome']   = 'Üdvözöljük, és köszönjük, hogy regisztrált a %s weboldalon!';
$_['text_denied']    = 'Sajnálattal értesítjük, hogy kérelmét elutasították. További információkért kérjük, lépjen kapcsolatba az áruház tulajdonosával az alábbi linken:';
$_['text_thanks']    = 'Köszönettel,';

// Button
$_['button_contact'] = 'Lépjen kapcsolatba velünk';
