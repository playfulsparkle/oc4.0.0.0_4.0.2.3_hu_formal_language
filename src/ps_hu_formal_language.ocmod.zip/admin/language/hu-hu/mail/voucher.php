<?php
// Text
$_['text_success']  = 'Siker: A kuponok módosítása sikeresen megtörtént!';
$_['text_subject']  = 'Ajándékutalványt kapott %s-től';
$_['text_greeting'] = 'Gratulálunk, Ön egy %s értékű Ajándékutalványt kapott!';
$_['text_from']     = 'Ezt az Ajándékutalványt %s küldte Önnek';
$_['text_message']  = 'Az üzenet a következő volt:';
$_['text_redeem']   = 'Az Ajándékutalvány beváltásához először is írja le a beváltási kódot, amely: <b>%s</b>. Ezután kattintson az alábbi linkre, és vásárolja meg azokat a termékeket, amelyekhez fel kívánja használni az utalványt. Végül a <b>Kosár</b> oldalon, a <b>Fizetés</b> gomb előtt adja meg az ajándékutalvány kódját.';
$_['text_footer']   = 'Kérjük, válaszoljon erre az e-mailre, ha bármilyen kérdése van.';
$_['text_sent']     = 'Siker: Az ajándékutalvány e-mailt sikeresen elküldtük!';
