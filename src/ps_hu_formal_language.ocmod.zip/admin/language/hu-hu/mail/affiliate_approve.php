<?php
// Text
$_['text_subject']  = '%s - Az Ön partner fiókja aktiválva lett!';
$_['text_welcome']  = 'Üdvözöljük és köszönjük, hogy regisztrált a %s oldalon!';
$_['text_login']    = 'Fiókja mostantól jóváhagyásra került, és bejelentkezhet e-mail címe és jelszava használatával weboldalunkon, vagy az alábbi URL-en:';
$_['text_service']  = 'A bejelentkezés után lehetősége lesz nyomkövető kódok generálására, jutalék kifizetések követésére és fiókjának adatait szerkeszteni.';
$_['text_thanks']   = 'Köszönjük,';
