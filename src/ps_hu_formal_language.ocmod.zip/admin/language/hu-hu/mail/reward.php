<?php
// Text
$_['text_subject']  = '%s - Bónuszpont';
$_['text_received'] = 'Ön %s bónuszpontot kapott!';
$_['text_total']    = 'A bónuszpontjainak összértéke most %s.';
