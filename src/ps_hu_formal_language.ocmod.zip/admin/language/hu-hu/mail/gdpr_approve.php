<?php
// Text
$_['text_subject'] = '%s - GDPR kérés jóváhagyva!';
$_['text_request'] = 'Fiók törlési kérelem';
$_['text_hello']   = 'Kedves <strong>%s</strong>,';
$_['text_user']    = 'Felhasználó';
$_['text_gdpr']    = 'A GDPR adat törlési kérelme jóváhagyásra került, és <strong>%s nap</strong> múlva törlésre kerül.';
$_['text_q']       = 'K: Miért nem töröljük azonnal az adatait?';
$_['text_a']       = 'V: A fiók törlési kérelmeket <strong>%s nap</strong> elteltével dolgozzuk fel, hogy a visszatérítések, chargebackek vagy csalásellenőrzések kezelhetők legyenek.';
$_['text_delete']  = 'Értesítést fog kapni, amikor a fiókja törlésre kerül.';
$_['text_thanks']  = 'Köszönettel,';
