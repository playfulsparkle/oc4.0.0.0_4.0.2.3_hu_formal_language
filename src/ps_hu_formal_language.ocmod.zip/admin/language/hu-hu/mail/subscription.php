<?php
// Text
$_['text_subject']             = '%s - Előfizetés';
$_['text_subscription_id']     = 'Előfizetés azonosító';
$_['text_date_added']          = 'Előfizetés dátuma:';
$_['text_subscription_status'] = 'Az Ön előfizetése az alábbi státuszra lett állítva:';
$_['text_comment']             = 'Az Ön előfizetéséhez tartozó megjegyzések:';
$_['text_payment_method']      = 'Fizetési módja';
$_['text_payment_code']        = 'Fizetési kód';
$_['text_footer']              = 'Kérjük, válaszoljon erre az e-mailre, ha bármilyen kérdése van.';
