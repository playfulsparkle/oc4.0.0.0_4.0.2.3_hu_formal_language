<?php
// Text
$_['text_subject'] = 'A biztonsági kód próbálkozásainak visszaállítása';
$_['text_reset']   = 'Valaki többször, mint 3 alkalommal hibásan adta meg a biztonsági kódot.';
$_['text_link']    = 'Kattintson az alábbi linkre a fiók biztonságának visszaállításához:';
$_['text_ip']      = 'IP:';
$_['text_regards'] = 'Üdvözlettel';
