<?php
// Text
$_['text_subject']  = '%s - Jelszó visszaállítási kérelem';
$_['text_greeting'] = 'Új jelszót kértek a %s adminisztrációs felülethez.';
$_['text_change']   = 'A jelszó visszaállításához kattintson az alábbi linkre:';
$_['text_ip']       = 'A kérelem benyújtásához használt IP cím:';
