<?php
// Text
$_['text_subject']   = '%s - GDPR kérés elutasítva!';
$_['text_export']    = 'Fiók adat exportálási kérelem';
$_['text_remove']    = 'Fiók Törlési Kérelem';
$_['text_hello']     = 'Kedves <strong>%s</strong>,';
$_['text_user']      = 'Felhasználó';
$_['text_contact']   = 'Sajnálatos módon a kérelme elutasításra került. További információért kérjük, lépjen kapcsolatba az áruházzal itt:';
$_['text_thanks']    = 'Köszönettel,';

// Button
$_['button_contact'] = 'Lépjen kapcsolatba velünk';
