<?php
// Text
$_['text_subject'] = '%s - Az Ön partner fiókját elutasították!';
$_['text_welcome'] = 'Üdvözöljük és köszönjük, hogy regisztrált a %s oldalon!';
$_['text_denied']  = 'Sajnálatos módon a kérelmét elutasították. További információkért az áruház tulajdonosával itt léphet kapcsolatba:';
$_['text_thanks']  = 'Köszönjük,';
