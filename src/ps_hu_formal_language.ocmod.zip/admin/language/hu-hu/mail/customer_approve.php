<?php
// Text
$_['text_subject'] = '%s - A fiókja aktiválva lett!';
$_['text_welcome'] = 'Üdvözöljük és köszönjük, hogy regisztrált a %s weboldalon!';
$_['text_login']   = 'A fiókja most már létrehozva lett. Bejelentkezhet az email címe és jelszava használatával, a weboldalunkon vagy az alábbi URL-en:';
$_['text_service'] = 'Bejelentkezés után hozzáférhet más szolgáltatásokhoz is, például korábbi rendelései megtekintéséhez, számlák kinyomtatásához és fiókadatai szerkesztéséhez.';
$_['text_thanks']  = 'Köszönettel,';

// Button
$_['button_login'] = 'Bejelentkezés';
