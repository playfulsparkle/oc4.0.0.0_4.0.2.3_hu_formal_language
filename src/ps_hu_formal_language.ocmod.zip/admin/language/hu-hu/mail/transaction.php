<?php
// Text
$_['text_subject']  = '%s - Partneri kreditek';
$_['text_received'] = 'Ön %s kreditet kapott!';
$_['text_total']    = 'A rendelkezésére álló teljes kredit összege mostantól %s.';
$_['text_credit']   = 'A számláján lévő kredit a következő vásárlásából levonásra kerülhet.';
