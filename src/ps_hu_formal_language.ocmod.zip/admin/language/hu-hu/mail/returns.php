<?php
// Text
$_['text_subject']       = '%s - Reklamáció Frissítés %s';
$_['text_return_id']     = 'Reklamáció azonosító:';
$_['text_date_added']    = 'Reklamáció dátuma:';
$_['text_return_status'] = 'A reklamációja a következő státuszra lett frissítve:';
$_['text_comment']       = 'A reklamációhoz fűzött megjegyzések:';
$_['text_footer']        = 'Kérjük, válaszoljon erre az e-mailre, ha bármilyen kérdése van.';
