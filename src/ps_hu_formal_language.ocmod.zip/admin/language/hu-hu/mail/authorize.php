<?php
// Text
$_['text_subject'] = 'Biztonság';
$_['text_code']    = 'A biztonsági kódot be kell írnia az admin biztonsági ellenőrzés során.';
$_['text_ip']      = 'IP:';
$_['text_regards'] = 'Üdvözlettel';
