<?php
// Text
$_['text_subject']   = '%s - GDPR kérés feldolgozva!';
$_['text_request']   = 'Fiók törlési kérelem';
$_['text_hello']     = 'Kedves <strong>%s</strong>,';
$_['text_user']      = 'Felhasználó';
$_['text_delete']    = 'A GDPR adat törlési kérelme mostanra feldolgozásra került.';
$_['text_contact']   = 'További információért kérjük, lépjen kapcsolatba az áruház tulajdonosával itt:';
$_['text_thanks']    = 'Köszönettel,';

// Button
$_['button_contact'] = 'Lépjen kapcsolatba velünk';
