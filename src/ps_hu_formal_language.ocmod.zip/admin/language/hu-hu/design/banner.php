<?php
// Heading
$_['heading_title']    = 'Bannerek';

// Text
$_['text_success']     = 'Siker: Sikeresen módosította a bannereket!';
$_['text_list']        = 'Banner lista';
$_['text_add']         = 'Banner hozzáadása';
$_['text_edit']        = 'Banner szerkesztése';
$_['text_default']     = 'Alapértelmezett';

// Column
$_['column_name']      = 'Banner név';
$_['column_status']    = 'Állapot';
$_['column_action']    = 'Művelet';

// Entry
$_['entry_name']       = 'Banner név';
$_['entry_title']      = 'Cím';
$_['entry_link']       = 'Link';
$_['entry_image']      = 'Kép';
$_['entry_status']     = 'Állapot';
$_['entry_sort_order'] = 'Sorrend';

// Error
$_['error_permission'] = 'Figyelem: Nincs engedélye a bannerek módosítására!';
$_['error_name']       = 'A banner név 3 és 64 karakter között kell legyen!';
$_['error_title']      = 'A banner címe 2 és 64 karakter között kell legyen!';
