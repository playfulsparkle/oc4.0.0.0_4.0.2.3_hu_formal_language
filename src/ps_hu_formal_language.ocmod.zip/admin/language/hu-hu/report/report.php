<?php
// Heading
$_['heading_title'] = 'Jelentések';

// Text
$_['text_success']  = 'Siker: Sikeresen módosította a jelentéseket!';
$_['text_type']     = 'Válassza ki a jelentés típusát';
$_['text_filter']   = 'Szűrő';
