<?php
// Cím
$_['heading_title']    = 'Magyar nyelv (magázó)';

// Szöveg
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: A magyar nyelvet sikeresen módosította!';
$_['text_edit']        = 'Magyar nyelv szerkesztése';

// Bejegyzés
$_['entry_status']     = 'Állapot';

// Hiba
$_['error_permission'] = 'Figyelem: Nincs jogosultsága a magyar nyelv módosításához!';
