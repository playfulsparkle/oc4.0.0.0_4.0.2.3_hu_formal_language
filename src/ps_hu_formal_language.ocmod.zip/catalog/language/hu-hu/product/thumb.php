<?php
// Text
$_['text_price'] = 'Ár:';
$_['text_tax']   = 'Áfa nélkül (nettó):';
