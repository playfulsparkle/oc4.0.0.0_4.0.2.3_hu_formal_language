<?php
// Heading
$_['heading_title']    = 'Gyártók';

// Text
$_['text_brand']       = 'Gyártók';
$_['text_index']       = 'Gyártó azonosító:';
$_['text_error']       = 'A gyártó nem található!';
$_['text_no_results']  = 'Nincsenek termékek a listázáshoz.';
$_['text_compare']     = '(%s) termék összehasonlítása';
$_['text_sort']        = 'Rendezés';
$_['text_default']     = 'Alapértelmezett';
$_['text_name_asc']    = 'Név (A - Z)';
$_['text_name_desc']   = 'Név (Z - A)';
$_['text_price_asc']   = 'Ár (legalacsonyabb &gt; legnagyobb)';
$_['text_price_desc']  = 'Ár (legnagyobb &gt; legalacsonyabb)';
$_['text_rating_asc']  = 'Értékelés (legrosszabb)';
$_['text_rating_desc'] = 'Értékelés (legjobb)';
$_['text_model_asc']   = 'Cikkszám (A - Z)';
$_['text_model_desc']  = 'Cikkszám (Z - A)';
$_['text_limit']       = 'Megjelenítés';
