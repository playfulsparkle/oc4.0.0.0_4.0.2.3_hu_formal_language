<?php
// Heading
$_['heading_title']    = 'Partner nyomkövetés';

// Text
$_['text_account']     = 'Fiók';
$_['text_description'] = 'Annak érdekében, hogy biztosan megkapja a jutalékot az általunk küldött ajánlásokért, nyomon kell követnünk az ajánlásokat azáltal, hogy nyomkövetési kódot helyezünk el az Ön által linkelt URL-ekben. Az alábbi eszközökkel generálhat linkeket a %s weboldalra.';

// Entry
$_['entry_code']       = 'Nyomkövetési kódja';
$_['entry_generator']  = 'Nyomkövetési hivatkozás generátor';
$_['entry_link']       = 'Nyomkövetési hivatkozás';

// Help
$_['help_generator']   = 'Írja be egy termék nevét, amelyre szeretne hivatkozást generálni';
