<?php
// Heading
$_['heading_title']      = 'Tranzakciói';

// Column
$_['column_date_added']  = 'Hozzáadva';
$_['column_description'] = 'Leírás';
$_['column_amount']      = 'Összeg (%s)';

// Text
$_['text_account']       = 'Fiók';
$_['text_transaction']   = 'Tranzakciói';
$_['text_total']         = 'Jelenlegi egyenlege:';
$_['text_no_results']    = 'Nincsenek tranzakciói!';
