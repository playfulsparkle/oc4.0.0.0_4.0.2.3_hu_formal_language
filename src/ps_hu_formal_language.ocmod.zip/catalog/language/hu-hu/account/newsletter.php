<?php
// Heading
$_['heading_title']    = 'Hírcsatorna feliratkozás';

// Text
$_['text_account']     = 'Fiók';
$_['text_newsletter']  = 'Hírcsatorna';
$_['text_success']     = 'Siker: A hírcsatorna feliratkozás sikeresen frissítve lett!';

// Entry
$_['entry_newsletter'] = 'Feliratkozás';
