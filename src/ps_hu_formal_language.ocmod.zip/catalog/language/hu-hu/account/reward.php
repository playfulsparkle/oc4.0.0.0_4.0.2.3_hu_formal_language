<?php
// Heading
$_['heading_title']      = 'Az Ön bónuszpontjai';

// Column
$_['column_date_added']  = 'Hozzáadva';
$_['column_description'] = 'Leírás';
$_['column_points']      = 'Bónuszpontok';

// Text
$_['text_account']       = 'Fiók';
$_['text_reward']        = 'Bónuszpontok';
$_['text_total']         = 'A bónuszpontok teljes száma:';
$_['text_no_results']    = 'Nincsenek bónuszpontjai!';
