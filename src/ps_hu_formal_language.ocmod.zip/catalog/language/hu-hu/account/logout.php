<?php
// Heading
$_['heading_title'] = 'Kijelentkezés';

// Text
$_['text_message']  = '<p>Sikeresen kijelentkezett a fiókjából. Most már biztonságosan elhagyhatja a számítógépet.</p><p>A bevásárlókosara elmentésre került, a benne lévő termékek visszaállításra kerülnek, amikor legközelebb bejelentkezik a fiókjába.</p>';
$_['text_account']  = 'Fiók';
$_['text_logout']   = 'Kijelentkezés';
