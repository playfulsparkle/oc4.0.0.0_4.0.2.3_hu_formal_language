<?php
// Heading
$_['heading_title']     = 'Letöltések';

// Text
$_['text_account']      = 'Fiók';
$_['text_downloads']    = 'Letöltések';
$_['text_no_results']   = 'Még nem rendelt letölthető termékeket!';

// Column
$_['column_order_id']   = 'Rendelés azonosító';
$_['column_name']       = 'Név';
$_['column_size']       = 'Méret';
$_['column_date_added'] = 'Hozzáadva';

// Error
$_['error_not_found']    = 'Hiba: A(z) %s fájl nem található!';
$_['error_headers_sent'] = 'Hiba: A fejléc már elküldésre került!';
