<?php
// Text
$_['text_subject']  = '%s - GDPR kérelem';
$_['text_export']   = 'Adat-export kérelem';
$_['text_remove']   = 'Fiók törlési kérelem';
$_['text_gdpr']     = 'Ez a GDPR kérelem az alábbi e-mail címről érkezett. Kérjük, erősítse meg ezt a műveletet az alábbi hivatkozásra kattintva:';
$_['text_ip']       = 'A kérés leadásához használt IP cím:';
$_['text_contact']  = 'Ha nem Ön kezdeményezte ezt a kérést, kérjük, lépjen kapcsolatba az áruház tulajdonosával itt:';
$_['text_thanks']   = 'Köszönjük,';
$_['text_ignore']   = 'Ha nem Ön indította ezt a kérést, kérjük, hagyja figyelmen kívül ezt az e-mailt.';

// Button
$_['button_export'] = 'Megerősítem az adataim exportálását';
$_['button_remove'] = 'Megerősítem a fiókom törlését';
