<?php
// Text
$_['text_subject']      = '%s - Rendelés frissítés %s';
$_['text_order_id']     = 'Rendelés azonosító:';
$_['text_date_added']   = 'Hozzáadás dátuma:';
$_['text_order_status'] = 'A rendelése a következő állapotra lett frissítve:';
$_['text_comment']      = 'A rendeléshez fűzött megjegyzések:';
$_['text_link']         = 'A rendelés megtekintéséhez kattintson az alábbi linkre:';
$_['text_footer']       = 'Kérjük, válaszoljon erre az e-mailre, ha bármilyen kérdése van.';
