<?php
// Text
$_['text_subject']  = '%s - Jelszó visszaállítási kérelem';
$_['text_greeting'] = 'Új jelszó igénylése történt a %s vásárlói fiókhoz.';
$_['text_change']   = 'A jelszó visszaállításához kattintson az alábbi linkre:';
$_['text_ip']       = 'A kérelem benyújtásához használt IP-cím:';

// Button
$_['button_reset']  = 'Jelszó visszaállítása';
