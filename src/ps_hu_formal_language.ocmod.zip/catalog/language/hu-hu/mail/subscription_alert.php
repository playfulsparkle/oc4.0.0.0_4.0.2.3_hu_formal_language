<?php
// Text
$_['text_subject']              = '%s - Rendelés %s - Lemondott előfizetés';
$_['text_received']             = 'Lemondott előfizetést kapott.';
$_['text_orders_id']            = 'Rendelés azonosító:';
$_['text_subscription_id']      = 'Előfizetés azonosító:';
$_['text_date_added']           = 'Dátum hozzáadva:';
$_['text_subscription_status']  = 'Előfizetés állapota:';
$_['text_comment']              = 'Az előfizetéshez tartozó megjegyzések:';
$_['text_canceled']             = 'Siker: Az előfizetés profilja lemondásra került!';
