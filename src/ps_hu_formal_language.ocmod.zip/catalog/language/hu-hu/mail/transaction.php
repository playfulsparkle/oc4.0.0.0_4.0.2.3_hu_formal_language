<?php
// Text
$_['text_subject']  = '%s - Partneri jutalék';
$_['text_received'] = 'Gratulálunk! Ön jutalékot kapott a %s partnerprogramból.';
$_['text_amount']   = 'A kapott összeg:';
$_['text_total']    = 'A jutalék összesen:';
