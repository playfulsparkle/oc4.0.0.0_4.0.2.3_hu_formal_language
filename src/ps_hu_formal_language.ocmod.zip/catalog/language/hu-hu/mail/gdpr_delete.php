<?php
// Text
$_['text_subject']   = '%s - GDPR kérés feldolgozva!';
$_['text_request']   = 'Fiók törlési kérelem';
$_['text_hello']     = 'Kedves <strong>%s</strong>,';
$_['text_user']      = 'Felhasználó';
$_['text_delete']    = 'A GDPR adatok törlésére vonatkozó kérését most már teljesítettük.';
$_['text_contact']   = 'További információkért itt léphet kapcsolatba az áruház tulajdonosával:';
$_['text_thanks']    = 'Köszönjük,';

// Button
$_['button_contact'] = 'Lépjen kapcsolatba velünk';
