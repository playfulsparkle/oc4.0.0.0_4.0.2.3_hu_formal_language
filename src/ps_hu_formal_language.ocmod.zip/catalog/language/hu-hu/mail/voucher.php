<?php
// Text
$_['text_subject']  = 'Ajándékutalványt kapott a %s-tól/től';
$_['text_greeting'] = 'Gratulálunk, ajándékutalványt kapott, amelynek értéke %s';
$_['text_from']     = 'Ezt az ajándékutalványt %s küldte Önnek';
$_['text_message']  = 'A következő üzenettel:';
$_['text_redeem']   = 'Az ajándékutalvány beváltásához jegyezze fel a beváltási kódot, amely: <b>%s</b>. Ezután kattintson az alábbi linkre, és vásárolja meg azt a terméket, amelyre az utalványt fel kívánja használni. Az ajándékutalvány kódját a bevásárlókosár oldalon adhatja meg a pénztár előtt.';
$_['text_footer']   = 'Kérjük, válaszoljon erre az e-mailre, ha bármilyen kérdése van.';
