<?php
// Text
$_['text_subject']  = '%s - Termékértékelés';
$_['text_waiting']  = 'Új termékértékelés vár jóváhagyásra.';
$_['text_product']  = 'Termék:';
$_['text_reviewer'] = 'Értékelő:';
$_['text_rating']   = 'Értékelés:';
$_['text_review']   = 'Értékelés szövege:';
