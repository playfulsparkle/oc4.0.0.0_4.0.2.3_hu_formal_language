<?php
// Text
$_['text_subject']      = '%s - Rendelés %s';
$_['text_received']     = 'Új rendelést kapott.';
$_['text_order_id']     = 'Rendelés azonosító:';
$_['text_date_added']   = 'Hozzáadás dátuma:';
$_['text_order_status'] = 'Rendelés állapot:';
$_['text_product']      = 'Termékek:';
$_['text_total']        = 'Összesen:';
$_['text_comment']      = 'A rendeléshez fűzött megjegyzések:';
