<?php
// Text
$_['text_success']     = 'Siker: Az API munkamenet sikeresen elindult!';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az API eléréséhez!';
$_['error_key']        = 'Figyelem: Hibás API kulcs!';
$_['error_ip']         = 'Figyelem: Az Ön IP címe (%s) nem jogosult az API elérésére!';
