<?php
// Text
$_['text_success'] = 'Siker: Az áruház sikeresen megváltozott!';

// Error
$_['error_store']  = 'Figyelem: Az áruház nem található!';
