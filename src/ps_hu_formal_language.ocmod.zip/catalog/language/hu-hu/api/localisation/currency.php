<?php
// Text
$_['text_success']   = 'Siker: A árfolyam sikeresen megváltozott!';

// Error
$_['error_currency'] = 'Figyelem: A valuta nem található!';
