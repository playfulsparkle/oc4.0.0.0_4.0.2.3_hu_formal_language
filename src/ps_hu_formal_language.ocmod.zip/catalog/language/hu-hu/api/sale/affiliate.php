<?php
// Text
$_['text_success']    = 'Siker: A partner jutalék alkalmazva lesz erre a rendelésre!';
$_['text_remove']     = 'Siker: A partner jutalékot eltávolítottuk!';

// Error
$_['error_affiliate'] = 'Figyelem: A partner nem található!';
