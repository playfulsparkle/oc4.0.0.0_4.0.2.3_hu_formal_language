<?php
// Text
$_['text_success'] = 'Siker: A kuponkedvezmény alkalmazva lett!';
$_['text_remove']  = 'Siker: A kuponkedvezmény eltávolítva!';

// Error
$_['error_coupon'] = 'Figyelem: A kupon érvénytelen, lejárt, vagy elérte a felhasználási limitet!';
