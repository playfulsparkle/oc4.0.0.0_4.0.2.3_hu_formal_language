<?php
// Text
$_['text_success']           = 'Siker: A szállítási mód beállítva lett!';

// Error
$_['error_shipping_address'] = 'Figyelem: Szállítási cím kötelező!';
$_['error_shipping_method']  = 'Figyelem: Szállítási mód kötelező!';
$_['error_no_shipping']      = 'Figyelem: Nincs elérhető szállítási lehetőség!';
$_['error_shipping']         = 'Figyelem: Nincsenek olyan termékek, amelyek szállítást igényelnek!';
