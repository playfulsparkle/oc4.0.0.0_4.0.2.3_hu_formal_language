<?php
// Text
$_['text_success']         = 'Sikeresen módosította az ügyfeleket';

// Error
$_['error_customer']       = 'Figyelem: Az ügyfél nem található!';
$_['error_customer_group'] = 'Az ügyfélcsoport nem tűnik érvényesnek!';
$_['error_firstname']      = 'A keresztnévnek 1 és 32 karakter között kell lennie!';
$_['error_lastname']       = 'A vezetéknévnek 1 és 32 karakter között kell lennie!';
$_['error_email']          = 'Az e-mail cím nem tűnik érvényesnek!';
$_['error_telephone']      = 'A telefonszámnak 3 és 32 karakter között kell lennie!';
$_['error_custom_field']   = '%s kötelező!';
$_['error_regex']          = '%s nem érvényes bemenet!';
