<?php
// Text
$_['text_success']          = 'Siker: A fizetési mód beállítva lett!';

// Error
$_['error_payment_address'] = 'Figyelem: Fizetési cím kötelező!';
$_['error_payment_method']  = 'Figyelem: Fizetési mód kötelező!';
$_['error_no_payment']      = 'Figyelem: Nincs elérhető fizetési lehetőség!';
$_['error_product']         = 'Figyelem: Termékek kötelezőek!';
