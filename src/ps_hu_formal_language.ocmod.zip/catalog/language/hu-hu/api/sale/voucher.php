<?php
// Text
$_['text_cart']       = 'Siker: Módosította a bevásárlókosarat!';
$_['text_for']        = '%s Ajándékutalvány %s számára';
$_['text_success']    = 'Siker: Az ajándékutalvány kedvezmény alkalmazva lett!';
$_['text_remove']     = 'Siker: Az ajándékutalvány kedvezmény eltávolítva!';

// Error
$_['error_voucher']   = 'Figyelem: Az ajándékutalvány érvénytelen, vagy az egyenleg felhasználásra került!';
$_['error_to_name']   = 'A címzett neve 1 és 64 karakter között kell legyen!';
$_['error_from_name'] = 'A saját neve 1 és 64 karakter között kell legyen!';
$_['error_email']     = 'Az e-mail cím nem tűnik érvényesnek!';
$_['error_theme']     = 'Válasszon egy témát!';
$_['error_amount']    = 'Az összegnek %s és %s között kell lennie!';
