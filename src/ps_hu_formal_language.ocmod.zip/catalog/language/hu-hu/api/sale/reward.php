<?php
// Text
$_['text_success']  = 'Siker: A bónuszpont kedvezmény alkalmazva lett!';
$_['text_remove']   = 'Siker: A bónuszpont kedvezmény eltávolítva!';

// Error
$_['error_reward']  = 'Figyelem: Kérjük, adja meg a felhasználni kívánt bónuszpontok számát!';
$_['error_points']  = 'Figyelem: Nincsenek %s bónuszpontjaid!';
$_['error_maximum'] = 'Figyelem: A maximálisan alkalmazható pontok száma %s!';
