<?php
// Text
$_['text_points']                = 'Bónuszpontok';
$_['text_subscription']          = 'Előfizetés';
$_['text_subscription_trial']    = '%s minden %d %s(napon) keresztül %d kifizetés(es) majd ';
$_['text_subscription_duration'] = '%s minden %d %s(napon) keresztül %d kifizetés(es)';
$_['text_subscription_cancel']   = '%s minden %d %s(napon) keresztül, amíg le nem mondják';
$_['text_day']                   = 'nap';
$_['text_week']                  = 'hét';
$_['text_semi_month']            = 'félhónap';
$_['text_month']                 = 'hónap';
$_['text_year']                  = 'év';

// Column
$_['column_name']                = 'Termék neve';
$_['column_model']               = 'Cikkszám';
$_['column_quantity']            = 'Mennyiség';
$_['column_price']               = 'Egységár';
$_['column_total']               = 'Összesen';
