<?php
// Heading
$_['heading_title'] = 'A rendelése sikeresen leadva!';

// Text
$_['text_basket']   = 'Kosár';
$_['text_checkout'] = 'Pénztár';
$_['text_success']  = 'Siker';
$_['text_customer'] = '<p>A rendelése sikeresen feldolgozásra került!</p><p>A rendelési előzményeit megtekintheti a <a href="%s">fiókom</a> oldalon, az <a href="%s">előzmények</a> menüpont alatt.</p><p>Ha a vásárlásához letöltés is tartozik, azokat a fiókjában található <a href="%s">letöltések</a> oldalon tekintheti meg.</p><p>Kérdéseivel forduljon a <a href="%s">bolt tulajdonosához</a>.</p><p>Köszönjük, hogy online vásárolt nálunk!</p>';
$_['text_guest']    = '<p>A rendelése sikeresen feldolgozásra került!</p><p>Kérdéseivel forduljon a <a href="%s">bolt tulajdonosához</a>.</p><p>Köszönjük, hogy online vásárolt nálunk!</p>';
