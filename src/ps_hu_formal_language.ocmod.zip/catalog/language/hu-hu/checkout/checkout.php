<?php
// Heading
$_['heading_title'] = 'Pénztár';

// Text
$_['text_cart']     = 'Bevásárlókosár';
