<?php
// Text
$_['text_currency'] = 'Valuta';