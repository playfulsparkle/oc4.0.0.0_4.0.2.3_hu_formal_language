<?php
// Heading
$_['heading_title']    = 'Karbantartás';

// Text
$_['text_maintenance'] = 'Karbantartás';
$_['text_message']     = '<h1 style="text-align:center;">Jelenleg ütemezett karbantartást végzünk. <br/>Hamarosan visszatérünk. Kérjük, nézzen vissza később.</h1>';
