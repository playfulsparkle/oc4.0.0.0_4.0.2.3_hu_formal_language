<?php
// Text
$_['text_category']  = 'Kategóriák';
$_['text_all']       = 'Összes megjelenítése';
