<?php
// Text
$_['text_search'] = 'Keresés';