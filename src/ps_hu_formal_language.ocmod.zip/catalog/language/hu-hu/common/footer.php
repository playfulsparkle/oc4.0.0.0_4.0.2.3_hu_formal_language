<?php
// Text
$_['text_information']  = 'Információk';
$_['text_blog']         = 'Blog';
$_['text_service']      = 'Vevőszolgálat';
$_['text_extra']        = 'Egyéb információk';
$_['text_contact']      = 'Kapcsolatfelvétel';
$_['text_return']       = 'Reklamáció';
$_['text_sitemap']      = 'Webhelytérkép';
$_['text_gdpr']         = 'GDPR';
$_['text_manufacturer'] = 'Gyártók';
$_['text_voucher']      = 'Ajándékutalványok';
$_['text_affiliate']    = 'Partnerprogram';
$_['text_special']      = 'Akciók';
$_['text_account']      = 'Fiók';
$_['text_order']        = 'Rendelés előzmények';
$_['text_wishlist']     = 'Kívánságlista';
$_['text_newsletter']   = 'Hírlevél';
$_['text_powered']      = '<a href="https://www.opencart.com">OpenCart</a> motor hajtja<br/> %s &copy; %s';
