<?php
// Text
$_['text_wishlist']      = 'Kívánságlista (%s)';
$_['text_shopping_cart'] = 'Bevásárló kosár';
$_['text_account']       = 'Fiók';
$_['text_register']      = 'Regisztráció';
$_['text_login']         = 'Bejelentkezés';
$_['text_order']         = 'Rendelések';
$_['text_transaction']   = 'Tranzakciók';
$_['text_download']      = 'Letöltések';
$_['text_logout']        = 'Kijelentkezés';
$_['text_checkout']      = 'Pénztár';
