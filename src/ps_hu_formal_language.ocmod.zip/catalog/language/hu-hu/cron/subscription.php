<?php
// Text
$_['text_success']           = 'Siker: Az előfizetési profil sikeresen megújult!';

// Error
$_['error_language']         = 'Figyelem: A kifizetési módszer kiterjesztés nem található!';
$_['error_customer']         = 'Figyelem: A kifizetési módszer kiterjesztés nem található!';
$_['error_product']          = 'Figyelem: A kifizetési módszer kiterjesztés nem található!';
$_['error_shipping_address'] = 'Figyelem: A kifizetési módszer kiterjesztés nem található!';
$_['error_shipping_method']  = 'Figyelem: A szállítási módszer %s nem található!';
$_['error_payment_address']  = 'Figyelem: A kifizetési módszer kiterjesztés nem található!';
$_['error_payment_method']   = 'Figyelem: A kifizetési módszer %s nem található!';
$_['error_extension']        = 'Figyelem: A kifizetési módszer kiterjesztés nem található!';
$_['error_recurring']        = 'Figyelem: A kifizetési módszer nem rendelkezik ismétlődő kifizetési lehetőséggel!';
