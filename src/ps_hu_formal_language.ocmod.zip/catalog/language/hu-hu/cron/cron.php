<?php
// Text
$_['text_success']     = 'Siker: A %s cron feladat sikeresen végrehajtásra került!';

// Error
$_['error_permission'] = 'Figyelem: Nincs engedélye a cron feladatok módosítására!';
