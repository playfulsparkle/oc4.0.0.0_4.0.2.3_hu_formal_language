<?php
// Heading
$_['heading_title'] = 'GDPR siker';

// Text
$_['text_account']  = 'Fiók';
$_['text_export']   = 'Az Ön fiókadatai exportálására vonatkozó kérés megérkezett.';
$_['text_remove']   = 'A GDPR szerinti fiók törlési kérelmek feldolgozása <strong>%s nap</strong> múlva történik, hogy bármilyen visszatérítést, csalás észlelést vagy chargeback-et kezelhessünk.';
