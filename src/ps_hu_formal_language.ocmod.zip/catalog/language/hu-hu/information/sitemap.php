<?php
// Heading
$_['heading_title']    = 'Webhelytérkép';

// Text
$_['text_special']     = 'Akciók';
$_['text_account']     = 'Fiók';
$_['text_edit']        = 'Fiókadatok';
$_['text_password']    = 'Jelszó';
$_['text_address']     = 'Címjegyzék';
$_['text_history']     = 'Rendelési előzmények';
$_['text_download']    = 'Letöltések';
$_['text_cart']        = 'Bevásárló kosár';
$_['text_checkout']    = 'Pénztár';
$_['text_search']      = 'Keresés';
$_['text_information'] = 'Információk';
$_['text_contact']     = 'Kapcsolatfelvétel';
