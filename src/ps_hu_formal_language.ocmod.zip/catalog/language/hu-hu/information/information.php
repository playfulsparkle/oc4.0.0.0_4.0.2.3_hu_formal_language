<?php
// Text
$_['text_error'] = 'Az információs oldal nem található!';
