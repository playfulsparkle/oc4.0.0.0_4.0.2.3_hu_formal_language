<?php
// Text
$_['text_upload']     = 'A fájl sikeresen feltöltésre került!';

// Error
$_['error_filename']  = 'A fájlnévnek 3 és 64 karakter között kell lennie!';
$_['error_file_type'] = 'Érvénytelen fájltípus!';
$_['error_upload']    = 'Feltöltés szükséges!';
