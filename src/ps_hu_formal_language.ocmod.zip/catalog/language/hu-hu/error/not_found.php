<?php
// Heading
$_['heading_title'] = 'A keresett oldal nem található!';

// Text
$_['text_error']    = 'A keresett oldal nem található.';
