<?php
// Heading
$_['heading_title']        = 'Utánvétes fizetés';

// Error
$_['error_order_id']       = 'Nincs rendelési azonosító a munkamenetben!';
$_['error_payment_method'] = 'A fizetési mód helytelen!';
