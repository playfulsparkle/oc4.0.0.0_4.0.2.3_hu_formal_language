<?php
// Heading
$_['heading_title']    = 'Csekk / Pénzutalvány';

// Text
$_['text_instruction'] = 'Csekk / Pénzutalványi utasítások';
$_['text_payable']     = 'Fizetendő: ';
$_['text_address']     = 'Küldendő: ';
$_['text_payment']     = 'A megrendelésed csak akkor kerül kiszállításra, amikor megkaptuk a kifizetést.';
