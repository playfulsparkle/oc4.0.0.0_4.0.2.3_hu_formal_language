<?php
// Heading
$_['heading_title']    = 'Banki átutalás';

// Text
$_['text_instruction'] = 'Banki átutalási utasítások';
$_['text_description'] = 'Kérjük, utalja át a teljes összeget az alábbi bankszámlára.';
$_['text_payment']     = 'A megrendelése csak akkor kerül kiszállításra, amikor megkaptuk a kifizetést.';
