<?php
// Heading
$_['heading_title'] = 'Súlyalapú szállítási költség';

// Text
$_['text_weight']   = 'Súly:';