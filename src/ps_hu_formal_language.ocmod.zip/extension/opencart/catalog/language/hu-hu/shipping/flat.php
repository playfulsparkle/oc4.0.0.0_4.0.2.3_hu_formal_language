<?php
// Heading
$_['heading_title']    = 'Átalánydíj';

// Text
$_['text_description'] = 'Átalánydíjas szállítás';