<?php
// Heading
$_['heading_title']    = 'Személyes átvétel';

// Text
$_['text_description'] = 'Személyes átvétel az üzletből';