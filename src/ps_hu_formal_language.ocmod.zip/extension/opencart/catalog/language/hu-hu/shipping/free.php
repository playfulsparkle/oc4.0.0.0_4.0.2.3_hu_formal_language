<?php
// Heading
$_['heading_title']    = 'Ingyenes szállítás';

// Text
$_['text_description'] = 'Ingyenes szállítás';