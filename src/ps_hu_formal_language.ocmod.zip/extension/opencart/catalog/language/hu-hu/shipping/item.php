<?php
// Heading
$_['heading_title']    = 'Cikkenkénti szállítási díj';

// Text
$_['text_description'] = 'Cikkenkénti szállítási díj';