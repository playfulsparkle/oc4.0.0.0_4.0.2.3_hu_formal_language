<?php
// Heading
$_['heading_title'] = 'Legtöbbet eladott';