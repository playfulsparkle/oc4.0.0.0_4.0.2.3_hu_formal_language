<?php
// Heading
$_['heading_title'] = 'Akciós termékek';