<?php
// Heading
$_['heading_title'] = 'Információ';

// Text
$_['text_contact']  = 'Kapcsolatfelvétel';
$_['text_sitemap']  = 'Webhelytérkép';
