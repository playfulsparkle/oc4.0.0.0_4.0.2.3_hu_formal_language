<?php
// Heading
$_['heading_title'] = 'Válasszon egy áruházat';

// Text
$_['text_default']  = 'Alapértelmezett';
$_['text_store']    = 'Kérjük, válassza ki azt az áruházat, amelyet meg szeretne látogatni.';
