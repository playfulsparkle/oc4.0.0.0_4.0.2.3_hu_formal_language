<?php
// Heading
$_['heading_title'] = 'Legújabb termékek';