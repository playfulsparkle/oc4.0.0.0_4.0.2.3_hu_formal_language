<?php
// Heading
$_['heading_title'] = 'Részletes keresés';