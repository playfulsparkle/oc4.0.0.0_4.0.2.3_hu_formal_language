<?php
// Text
$_['text_handling'] = 'Kezelési költség';