<?php
// Text
$_['text_credit']   = 'Áruházi kredit';
$_['text_order_id'] = 'Rendelés azonosító: #%s';
