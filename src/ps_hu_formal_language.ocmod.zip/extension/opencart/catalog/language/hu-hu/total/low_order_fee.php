<?php
// Text
$_['text_low_order_fee'] = 'Kisösszegű rendelés költsége';