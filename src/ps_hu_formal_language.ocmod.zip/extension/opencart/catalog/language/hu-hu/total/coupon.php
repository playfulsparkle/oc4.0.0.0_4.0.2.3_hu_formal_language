<?php
// Heading
$_['heading_title'] = 'Kuponkód felhasználása';

// Text
$_['text_coupon']   = 'Kupon (%s)';
$_['text_success']  = 'Siker: A kuponkedvezmény alkalmazva!';
$_['text_remove']   = 'Siker: A kuponkedvezmény eltávolítva!';

// Entry
$_['entry_coupon']  = 'Írja be a kuponkódot itt';

// Error
$_['error_coupon']  = 'Figyelem: A kupon érvénytelen, lejárt vagy elérte a felhasználási limitet!';
$_['error_status']  = 'Figyelem: A kuponok nincsenek engedélyezve ezen a áruházban!';
