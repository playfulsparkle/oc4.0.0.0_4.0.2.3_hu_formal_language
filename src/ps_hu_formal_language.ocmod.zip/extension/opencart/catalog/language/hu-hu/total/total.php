<?php
// Text
$_['text_total'] = 'Összesen (bruttó)';