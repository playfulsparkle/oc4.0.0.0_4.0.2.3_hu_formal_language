<?php
// Heading
$_['heading_title']    = 'Alap CAPTCHA';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: Az alap CAPTCHA sikeresen módosítva lett!';
$_['text_edit']        = 'Serkesztés';

// Entry
$_['entry_status']     = 'Állapot';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az Alap CAPTCHA módosításához!';
