<?php
// Heading
$_['heading_title']    = 'Európai Központi Bank valutaátváltása (EKB)';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: A Európai Központi Bank valutaátváltása (EKB) sikeresen módosítva lett!';
$_['text_edit']        = 'EKB szerkesztése';
$_['text_support']     = 'Ez a bővítmény megköveteli, hogy az EUR pénznem elérhető legyen a pénznem opciók között.';

// Entry
$_['entry_status']     = 'Állapot';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága a Európai Központi Bank valutaátváltása (EKB) módosításához!';
