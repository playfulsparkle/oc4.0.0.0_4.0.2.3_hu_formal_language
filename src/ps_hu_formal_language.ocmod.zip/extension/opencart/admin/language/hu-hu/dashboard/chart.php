<?php
// Heading
$_['heading_title']    = 'Értékesítési elemzés diagram';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: Az irányítópult diagramja sikeresen módosítva lett!';
$_['text_edit']        = 'Értékesítési elemzés diagram szerkesztése';
$_['text_order']       = 'Rendelések';
$_['text_customer']    = 'Vásárlók';
$_['text_day']         = 'Ma';
$_['text_week']        = 'Hét';
$_['text_month']       = 'Hónap';
$_['text_year']        = 'Év';

// Entry
$_['entry_status']     = 'Állapot';
$_['entry_sort_order'] = 'Sorrend';
$_['entry_width']      = 'Szélesség';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az irányítópult diagram módosításához!';
