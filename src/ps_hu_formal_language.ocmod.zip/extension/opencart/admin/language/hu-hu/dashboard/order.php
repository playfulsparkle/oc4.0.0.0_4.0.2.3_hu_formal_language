<?php
// Heading
$_['heading_title']    = 'Összes rendelés';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: Az összes rendelés módosítása sikeresen megtörtént!';
$_['text_edit']        = 'Összes rendelés szerkesztése';
$_['text_view']        = 'Továbbiak megtekintése...';

// Entry
$_['entry_status']     = 'Állapot';
$_['entry_sort_order'] = 'Sorrend';
$_['entry_width']      = 'Szélesség';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az összes rendelés módosításához!';
