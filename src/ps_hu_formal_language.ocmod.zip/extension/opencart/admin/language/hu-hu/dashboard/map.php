<?php
// Heading
$_['heading_title']    = 'Világtérkép';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: Az világtérkép módosítása sikeresen megtörtént!';
$_['text_edit']        = 'Világtérkép szerkesztése';
$_['text_order']       = 'Rendelések';
$_['text_sale']        = 'Akciók';

// Entry
$_['entry_status']     = 'Állapot';
$_['entry_sort_order'] = 'Sorrend';
$_['entry_width']      = 'Szélesség';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az világtérkép módosításához!';
