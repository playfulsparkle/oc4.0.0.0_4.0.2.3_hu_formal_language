<?php
// Heading
$_['heading_title']    = 'Összes értékesítés';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: Az összes értékesítés módosítása sikeresen megtörtént!';
$_['text_edit']        = 'Összes értékesítés szerkesztése';
$_['text_view']        = 'További megtekintése...';

// Entry
$_['entry_status']     = 'Állapot';
$_['entry_sort_order'] = 'Sorrend';
$_['entry_width']      = 'Szélesség';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az összes értékesítés módosításához!';
