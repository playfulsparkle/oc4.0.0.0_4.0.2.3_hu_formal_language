<?php
// Heading
$_['heading_title']    = 'Alapértelmezett téma';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: A alapértelmezett téma sikeresen módosítva lett!';
$_['text_edit']        = 'Alapértelmezett téma szerkesztése';

// Entry
$_['entry_status']     = 'Állapot';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az alapértelmezett téma módosításához!';
