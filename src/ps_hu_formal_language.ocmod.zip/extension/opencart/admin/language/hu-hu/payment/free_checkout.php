<?php
// Heading
$_['heading_title']      = 'Ingyenes fizetés';

// Text
$_['text_extension']     = 'Bővítmények';
$_['text_success']       = 'Siker: Az ingyenes fizetés modul sikeresen módosítva lett!';
$_['text_edit']          = 'Ingyenes fizetés szerkesztése';

// Entry
$_['entry_order_status'] = 'Rendelés állapot';
$_['entry_status']       = 'Állapot';
$_['entry_sort_order']   = 'Sorrend';

// Error
$_['error_permission']   = 'Figyelem: Nincs jogosultsága az ingyenes fizetés módosításához!';
