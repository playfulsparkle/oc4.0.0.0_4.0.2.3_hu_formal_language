<?php
// Heading
$_['heading_title']    = 'Cikkenkénti szállítási költség';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: A cikkenkénti szállítási költség sikeresen módosítva lett!';
$_['text_edit']        = 'Cikkenkénti szállítási költség szerkesztése';

// Entry
$_['entry_cost']       = 'Díj';
$_['entry_tax_class']  = 'Adóosztály';
$_['entry_geo_zone']   = 'Adózónák';
$_['entry_status']     = 'Állapot';
$_['entry_sort_order'] = 'Sorrend';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága a cikkenkénti szállítási költségi díjak módosításához!';
