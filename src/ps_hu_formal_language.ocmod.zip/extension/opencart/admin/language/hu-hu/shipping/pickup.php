<?php
// Heading
$_['heading_title']    = 'Átvétel az áruházban';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: Az átvétel az áruházban sikeresen módosítva lett!';
$_['text_edit']        = 'Átvétel az áruházban szerkesztése';

// Entry
$_['entry_geo_zone']   = 'Adózónák';
$_['entry_status']     = 'Állapot';
$_['entry_sort_order'] = 'Sorrend';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az átvétel az áruházban módosításához!';
