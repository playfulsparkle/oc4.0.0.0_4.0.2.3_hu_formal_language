<?php
// Heading
$_['heading_title']    = 'Átalánydíj';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: A átalánydíj sikeresen módosítva lett!';
$_['text_edit']        = 'Átalánydíj szerkesztése';

// Entry
$_['entry_cost']       = 'Költség';
$_['entry_tax_class']  = 'Adóosztály';
$_['entry_geo_zone']   = 'Adózónák';
$_['entry_status']     = 'Állapot';
$_['entry_sort_order'] = 'Sorrend';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága a átalánydíj módosításához!';
