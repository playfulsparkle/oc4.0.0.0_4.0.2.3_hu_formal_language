<?php
// Heading
$_['heading_title']         = 'Vásárlói előfizetés jelentés';

// Text
$_['text_extension']        = 'Bővítmények';
$_['text_edit']             = 'Vásárlói előfizetés jelentés szerkesztése';
$_['text_success']          = 'Siker: A vásárlói előfizetés jelentés sikeresen módosítva lett!';
$_['text_filter']           = 'Szűrő';

// Column
$_['column_customer']       = 'Vásárló';
$_['column_email']          = 'E-mail';
$_['column_customer_group'] = 'Vásárlói csoport';
$_['column_status']         = 'Állapot';
$_['column_total']          = 'Összesen';
$_['column_action']         = 'Művelet';

// Entry
$_['entry_date_start']      = 'Kezdő dátum';
$_['entry_date_end']        = 'Záró dátum';
$_['entry_customer']        = 'Vásárló';
$_['entry_status']          = 'Állapot';
$_['entry_sort_order']      = 'Sorrend';

// Error
$_['error_permission']      = 'Figyelem: Nincs jogosultsága a vásárlói előfizetés jelentés módosításához!';
