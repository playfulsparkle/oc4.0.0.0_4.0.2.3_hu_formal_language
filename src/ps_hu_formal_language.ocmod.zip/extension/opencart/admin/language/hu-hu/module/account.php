<?php
// Heading
$_['heading_title']    = 'Fiók';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: A fiók modul sikeresen módosítva lett!';
$_['text_edit']        = 'Fiók szerkesztése';

// Entry
$_['entry_status']     = 'Állapot';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága a fiók modul módosításához!';
