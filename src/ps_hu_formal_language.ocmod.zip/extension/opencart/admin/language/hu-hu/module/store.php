<?php
// Heading
$_['heading_title']    = 'Áruház';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: Az áruház modul sikeresen módosítva lett!';
$_['text_edit']        = 'Áruház szerkesztése';

// Entry
$_['entry_admin']      = 'Csak adminsztráto felhasználók';
$_['entry_status']     = 'Állapot';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az áruház modul módosításához!';
