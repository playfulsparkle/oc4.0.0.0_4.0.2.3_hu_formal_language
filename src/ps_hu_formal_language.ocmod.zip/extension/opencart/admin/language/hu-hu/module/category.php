<?php
// Heading
$_['heading_title']    = 'Kategória';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: A kategória modul sikeresen módosítva lett!';
$_['text_edit']        = 'Kategória szerkesztése';

// Entry
$_['entry_status']     = 'Állapot';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága a kategória modul módosításához!';
