<?php
// Heading
$_['heading_title']    = 'Információ';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: Az információ modul sikeresen módosítva lett!';
$_['text_edit']        = 'Információ szerkesztése';

// Entry
$_['entry_status']     = 'Állapot';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az információ modul módosításához!';
