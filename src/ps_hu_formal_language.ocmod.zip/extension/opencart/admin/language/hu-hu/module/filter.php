<?php
// Heading
$_['heading_title']    = 'Szűrő';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: A szűrő modul sikeresen módosítva lett!';
$_['text_edit']        = 'Szűrő szerkesztése';

// Entry
$_['entry_status']     = 'Állapot';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága a szűrő modul módosításához!';
