<?php
// Heading
$_['heading_title']    = 'Szállítás';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: A szállítási költség sikeresen módosítva lett!';
$_['text_edit']        = 'Szállítás szerkesztése';

// Entry
$_['entry_estimator']  = 'Szállítási költség becslő';
$_['entry_status']     = 'Állapot';
$_['entry_sort_order'] = 'Sorrend';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága a szállítási költség módosításához!';
