<?php
// Heading
$_['heading_title']    = 'Kupon';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: A kupon összeg sikeresen módosítva lett!';
$_['text_edit']        = 'Kupon Szerkesztése';

// Entry
$_['entry_status']     = 'Állapot';
$_['entry_sort_order'] = 'Sorrend';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága a kupon összeg módosításához!';
