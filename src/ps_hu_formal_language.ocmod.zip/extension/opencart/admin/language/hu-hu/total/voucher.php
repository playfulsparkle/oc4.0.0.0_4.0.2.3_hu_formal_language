<?php
// Heading
$_['heading_title']    = 'Ajándékutalvány';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: Az ajándékutalvány összeg sikeresen módosítva lett!';
$_['text_edit']        = 'Ajándékutalvány szerkesztése';

// Entry
$_['entry_status']     = 'Állapot';
$_['entry_sort_order'] = 'Sorrend';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az ajándékutalvány összeg módosításához!';
