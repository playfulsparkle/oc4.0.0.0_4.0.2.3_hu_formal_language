<?php
// Heading
$_['heading_title']    = 'Adó';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: A adók összeg sikeresen módosítva lett!';
$_['text_edit']        = 'Adó szerkesztése';

// Entry
$_['entry_status']     = 'Állapot';
$_['entry_sort_order'] = 'Sorrend';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az adók módosításához!';
