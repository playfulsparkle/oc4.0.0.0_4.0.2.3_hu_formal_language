<?php
// Heading
$_['heading_title']    = 'Összesen (bruttó)';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: Az összesen összeg sikeresen módosítva lett!';
$_['text_edit']        = 'Összesen szerkesztése';

// Entry
$_['entry_status']     = 'Állapot';
$_['entry_sort_order'] = 'Sorrend';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az összesen összeg módosításához!';
