<?php
// Heading
$_['heading_title']    = 'Áruház kredit';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: Az áruház kredit összeg sikeresen módosítva lett!';
$_['text_edit']        = 'Áruház kredit szerkesztése';

// Entry
$_['entry_status']     = 'Állapot';
$_['entry_sort_order'] = 'Sorrend';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága az áruház kredit összeg módosításához!';
