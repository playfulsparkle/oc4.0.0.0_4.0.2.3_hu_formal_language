<?php
// Heading
$_['heading_title']    = 'Részösszeg (netto)';

// Text
$_['text_extension']   = 'Bővítmények';
$_['text_success']     = 'Siker: A részösszeg összegét sikeresen módosítva lett!';
$_['text_edit']        = 'Részösszeg szerkesztése';

// Entry
$_['entry_status']     = 'Állapot';
$_['entry_sort_order'] = 'Sorrend';

// Error
$_['error_permission'] = 'Figyelem: Nincs jogosultsága a részösszeg módosításához!';
